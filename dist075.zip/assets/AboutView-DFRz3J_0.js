import{_ as e,c,o}from"./index-CfxzbkFV.js";const t={};function n(r,s){return o(),c("div",null,"About")}const a=e(t,[["render",n]]);export{a as default};
